# يولّد أيقونات أندرويد من icon.png و icon_fg.png بعد إنشاء مشروع android
import os
from PIL import Image, ImageDraw

base = "android/app/src/main/res"
legacy = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
fore = {"mdpi": 108, "hdpi": 162, "xhdpi": 216, "xxhdpi": 324, "xxxhdpi": 432}
icon = Image.open("icon.png").convert("RGBA")
icon_fg = Image.open("icon_fg.png").convert("RGBA")

for d, s in legacy.items():
    folder = f"{base}/mipmap-{d}"
    os.makedirs(folder, exist_ok=True)
    im = icon.resize((s, s), Image.LANCZOS)
    im.save(f"{folder}/ic_launcher.png")
    mask = Image.new("L", (s, s), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, s - 1, s - 1), fill=255)
    rd = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    rd.paste(im, (0, 0), mask)
    rd.save(f"{folder}/ic_launcher_round.png")
    f = fore[d]
    icon_fg.resize((f, f), Image.LANCZOS).save(f"{folder}/ic_launcher_foreground.png")

xml = '''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">
    <background android:drawable="@color/ic_launcher_background"/>
    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>
</adaptive-icon>
'''
os.makedirs(f"{base}/mipmap-anydpi-v26", exist_ok=True)
for n in ("ic_launcher.xml", "ic_launcher_round.xml"):
    open(f"{base}/mipmap-anydpi-v26/{n}", "w", encoding="utf-8").write(xml)
os.makedirs(f"{base}/values", exist_ok=True)
open(f"{base}/values/ic_launcher_background.xml", "w", encoding="utf-8").write(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">#050505</color>\n</resources>\n')
print("icons done")
