# مستودعي — بناء ملف APK عبر GitHub

## لتحديث التطبيق (المستودع جاهز مسبقاً) — أسهل طريقة
1. افتح مستودعك على GitHub ← **Add file ← Upload files**.
2. ارفع ملف `mustawdai-apk-project.zip` الجديد **بنفس الاسم** (يستبدل القديم) ثم **Commit changes**.
3. افتح تبويب **Actions** وانتظر 6–12 دقيقة حتى تظهر علامة ✅.
4. حمّل الـ APK من **Releases ← latest ← Mustawdai.apk** وثبّته فوق القديم.

> رقم الإصدار يُقرأ تلقائياً من `const VER` داخل `index.html`، ويرتفع رقم البناء (versionCode) مع كل إصدار جديد، فيقبل أندرويد التحديث فوق النسخة المثبّتة بدون حذف بياناتك.
> لا ترفع `index.html` منفصلاً؛ ارفع دائماً الـ ZIP الجديد فقط.

## أول مرة (مستودع جديد)
1. أنشئ مستودعاً جديداً على github.com.
2. أضف الأسرار الثلاثة من ملف `GITHUB-SECRETS.txt`:
   Settings ← Secrets and variables ← Actions ← New repository secret:
   `ANDROID_KEY_ALIAS` و`ANDROID_KEYSTORE_PASSWORD` و`ANDROID_KEYSTORE_BASE64`.
3. ارفع الـ ZIP: **Add file ← Upload files** ثم **Commit changes**.
4. **Add file ← Create new file**، واكتب الاسم بالضبط `.github/workflows/build-apk.yml`، والصق محتوى الملف `build-apk.yml` المرفق، ثم **Commit changes** (هذا يبدأ البناء).

## تحديث ملف البناء (مرة واحدة، موصى به)
افتح `.github/workflows/build-apk.yml` في مستودعك ← أيقونة القلم ✏️ ← احذف كل المحتوى والصق محتوى `build-apk.yml` الجديد ← Commit.
(الجديد: يختار أحدث ZIP تلقائياً إن رفعت أكثر من واحد، ويحسب رقم البناء من رقم الإصدار.)

## ملاحظات
- لا ترفع `GITHUB-SECRETS.txt` إلى المستودع أبداً.
- إن رفض أندرويد التثبيت فوق نسخة قديمة فالتوقيع مختلف: خذ نسخة احتياطية كملف من الإعدادات، احذف القديم، ثبّت الجديد، ثم استعد من الملف.
- بياناتك على هاتفك فقط؛ خذ نسخة احتياطية بين فترة وأخرى.
